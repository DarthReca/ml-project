# -*- coding: utf-8 -*-
"""
Created on Mon May  3 10:31:22 2021

@author: Darth Reca
"""

import numpy as np

def k_fold(data: np.ndarray, k: int):
    pass